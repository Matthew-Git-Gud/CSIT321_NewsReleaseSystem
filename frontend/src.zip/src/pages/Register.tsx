import { type FormEvent, useState } from "react";
import {
  Link,
  useNavigate,
} from "react-router-dom";

import { register } from "../services/auth";
import "../styles/Auth.css";

import ThemeToggle from "../components/ThemeToggle";

type RegisterProps = {
  theme: "light" | "dark";
  onToggleTheme: () => void;
};

function Register({
  theme,
  onToggleTheme,
}: RegisterProps) {
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] =
    useState("");

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const handleSubmit = async (
    event: FormEvent<HTMLFormElement>,
  ) => {
    event.preventDefault();

    setError("");

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    setLoading(true);

    try {
      await register({
        full_name: fullName,
        username,
        email,
        password,
      });

      navigate("/login");
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : "Unable to create account",
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="auth-page">
      <button
        className="auth-back"
        type="button"
        onClick={() => navigate(-1)}
      >
        ← Back
      </button>
      {/* Theme control available before registration */}
      <div className="auth-theme-control">
        <ThemeToggle
          theme={theme}
          onToggle={onToggleTheme}
        />
      </div>

      <section className="auth-card">
        <Link
          className="brand auth-brand"
          to="/"
        >
          News Release System
        </Link>

        <div className="auth-heading">
          <p className="eyebrow">
            Join the community
          </p>

          <h1>
            Create your account.
          </h1>

          <p>
            Register to publish stories,
            comment, save articles and
            personalise your news feed.
          </p>
        </div>

        <form
          className="auth-form"
          onSubmit={handleSubmit}
        >
          <label htmlFor="register-name">
            Full name
          </label>

          <input
            id="register-name"
            type="text"
            value={fullName}
            onChange={(event) =>
              setFullName(event.target.value)
            }
            placeholder="Your full name"
            autoComplete="name"
            required
          />

          <label htmlFor="register-username">
            Username
          </label>

          <input
            id="register-username"
            type="text"
            value={username}
            onChange={(event) =>
              setUsername(event.target.value)
            }
            placeholder="Choose a username"
            autoComplete="username"
            required
          />

          <label htmlFor="register-email">
            Email
          </label>

          <input
            id="register-email"
            type="email"
            value={email}
            onChange={(event) =>
              setEmail(event.target.value)
            }
            placeholder="you@example.com"
            autoComplete="email"
            required
          />

          <label htmlFor="register-password">
            Password
          </label>

          <input
            id="register-password"
            type="password"
            value={password}
            onChange={(event) =>
              setPassword(event.target.value)
            }
            placeholder="Create a password"
            autoComplete="new-password"
            required
          />

          <label htmlFor="register-confirm-password">
            Confirm password
          </label>

          <input
            id="register-confirm-password"
            type="password"
            value={confirmPassword}
            onChange={(event) =>
              setConfirmPassword(event.target.value)
            }
            placeholder="Re-enter your password"
            autoComplete="new-password"
            required
          />

          {error && (
            <p className="form-error">
              {error}
            </p>
          )}

          <button
            className="primary-button auth-submit"
            type="submit"
            disabled={loading}
          >
            {loading
              ? "Creating account..."
              : "Create account"}
          </button>
        </form>

        <p className="auth-switch">
          Already have an account?

          <button
            type="button"
            onClick={() =>
              navigate("/login")
            }
          >
            Sign in
          </button>
        </p>
      </section>
    </main>
  );
}

export default Register;