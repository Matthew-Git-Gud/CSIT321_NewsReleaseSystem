const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT),
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,

    ssl: {
        rejectUnauthorized: false
    }
});

async function testConnection() {
    try {
        const connection = await pool.getConnection();

        console.log('Database connected successfully!');

        connection.release();
    } catch (error) {
        console.error('Database connection failed:');
        console.error(error);
    }
}

// testConnection();

module.exports = pool;